import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Header from "@/components/header"
import Sidebar from "@/components/sidebar"
import { StoreProvider } from "@/context/store-context"
import { Toaster } from "@/components/ui/toaster"
import CartDrawer from "@/components/cart-drawer"
import { SessionProvider } from "next-auth/react"
import type React from "react" // Added import for React

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Jumia Kenya - Online Shopping",
  description: "Online shopping in Kenya: Electronics, Fashion, Home & more",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <SessionProvider>
          <StoreProvider>
            <Header />
            <div className="flex">
              <Sidebar />
              <main className="flex-1">{children}</main>
            </div>
            <CartDrawer />
            <Toaster />
          </StoreProvider>
        </SessionProvider>
      </body>
    </html>
  )
}

