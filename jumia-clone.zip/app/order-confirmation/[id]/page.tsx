import { fetchOrders } from "@/utils/api"
import { notFound } from "next/navigation"

export default async function OrderConfirmation({ params }: { params: { id: string } }) {
  const orders = await fetchOrders()
  const order = orders.find((o) => o.id === Number.parseInt(params.id))

  if (!order) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">Order Confirmation</h1>
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Order #{order.id}</h2>
        <p className="mb-2">Status: {order.status}</p>
        <p className="mb-4">Total: KSh {order.total.toLocaleString()}</p>
        <h3 className="text-lg font-semibold mb-2">Items:</h3>
        <ul className="list-disc pl-5">
          {order.items.map((item: any) => (
            <li key={item.id}>
              {item.product.name} - Quantity: {item.quantity}, Price: KSh {item.price.toLocaleString()}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

