import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const category = searchParams.get("category")
  const search = searchParams.get("search")
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "10")
  const sortBy = searchParams.get("sortBy") || "name"
  const order = searchParams.get("order") || "asc"

  const skip = (page - 1) * limit

  const whereClause: any = {}

  if (category) {
    whereClause.category = category
  }

  if (search) {
    whereClause.OR = [{ name: { contains: search } }, { description: { contains: search } }]
  }

  try {
    const [products, total] = await Promise.all([
      prisma.product.findMany({
        where: whereClause,
        skip,
        take: limit,
        orderBy: { [sortBy]: order },
        include: {
          reviews: {
            select: {
              rating: true,
            },
          },
        },
      }),
      prisma.product.count({ where: whereClause }),
    ])

    const productsWithAvgRating = products.map((product) => ({
      ...product,
      rating:
        product.reviews.length > 0
          ? product.reviews.reduce((sum, review) => sum + review.rating, 0) / product.reviews.length
          : 0,
      reviews: undefined,
    }))

    return NextResponse.json({
      products: productsWithAvgRating,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    })
  } catch (error) {
    console.error("Error fetching products:", error)
    return NextResponse.json({ error: "Error fetching products" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const productData = await req.json()
    const product = await prisma.product.create({
      data: productData,
    })
    return NextResponse.json(product, { status: 201 })
  } catch (error) {
    console.error("Error creating product:", error)
    return NextResponse.json({ error: "Error creating product" }, { status: 500 })
  }
}

