import ProductCard from "@/components/product-card"
import Image from "next/image"
import { fetchProducts } from "@/utils/api"
import Pagination from "@/components/pagination"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export default async function Home({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  const page = typeof searchParams.page === "string" ? Number.parseInt(searchParams.page) : 1
  const limit = 10
  const category = typeof searchParams.category === "string" ? searchParams.category : undefined
  const search = typeof searchParams.search === "string" ? searchParams.search : undefined

  const { products, total, totalPages } = await fetchProducts({ page, limit, category, search })

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-8">
        <Image
          src="/placeholder.svg"
          alt="Flash Sales Banner"
          width={1200}
          height={400}
          className="rounded-lg w-full"
        />
      </div>

      <div className="mb-8">
        <form className="flex gap-4">
          <Input type="text" name="search" placeholder="Search products..." defaultValue={search} />
          <Button type="submit">Search</Button>
        </form>
      </div>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Flash Sales | Live Now</h2>
          <a href="#" className="text-orange-500">
            SEE ALL →
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <Pagination
          currentPage={page}
          totalPages={totalPages}
          onPageChange={(newPage) => {
            const url = new URL(window.location.href)
            url.searchParams.set("page", newPage.toString())
            window.location.href = url.toString()
          }}
        />
      </section>
    </div>
  )
}

