import { fetchProduct } from "@/utils/api"
import Image from "next/image"
import { notFound } from "next/navigation"
import AddToCartButton from "@/components/add-to-cart-button"
import ReviewSection from "@/components/review-section"
import Star from "@/components/star" // Import the Star component

export default async function ProductPage({ params }: { params: { id: string } }) {
  const product = await fetchProduct(Number.parseInt(params.id))

  if (!product) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            width={500}
            height={500}
            className="w-full rounded-lg"
          />
        </div>
        <div>
          <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
          <div className="flex items-center mb-4">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-5 w-5 ${
                  i < Math.round(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                }`}
              />
            ))}
            <span className="ml-2 text-gray-600">({product.reviews.length} reviews)</span>
          </div>
          <p className="text-xl font-bold mb-2">KSh {product.price.toLocaleString()}</p>
          <p className="text-gray-500 line-through mb-4">KSh {product.originalPrice.toLocaleString()}</p>
          <p className="mb-4">{product.description}</p>
          <p className="mb-4">Items left: {product.itemsLeft}</p>
          <AddToCartButton product={product} />
        </div>
      </div>
      <ReviewSection productId={product.id} />
    </div>
  )
}

