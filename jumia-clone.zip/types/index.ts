export interface Product {
  id: number
  name: string
  price: number
  originalPrice: number
  discount: number
  image: string
  itemsLeft: number //Fixed: int changed to number
  description: string
  category: string
  rating: number
  reviews: Review[]
}

export interface CartItem extends Product {
  quantity: number
}

export interface User {
  id: string
  email: string
  name?: string
  image?: string
}

export interface Review {
  id: number
  userId: string
  productId: number
  rating: number
  comment: string
  createdAt: Date
}

export interface Order {
  id: number
  userId: string
  total: number
  status: "PENDING" | "PROCESSING" | "SHIPPED" | "DELIVERED" | "CANCELLED"
  items: OrderItem[]
  shippingAddress: string
  createdAt: Date
}

export interface OrderItem {
  id: number
  productId: number
  quantity: number
  price: number
}

