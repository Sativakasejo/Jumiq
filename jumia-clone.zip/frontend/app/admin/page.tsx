"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import type { Product } from "@/types"
import { fetchProducts, createProduct, updateProduct, deleteProduct } from "@/utils/api"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

export default function AdminPanel() {
  const [products, setProducts] = useState<Product[]>([])
  const [newProduct, setNewProduct] = useState<Partial<Product>>({})
  const { toast } = useToast()
  const router = useRouter()

  useEffect(() => {
    loadProducts()
  }, [])

  const loadProducts = async () => {
    try {
      const { products } = await fetchProducts()
      setProducts(products)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load products",
        variant: "destructive",
      })
    }
  }

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await createProduct(newProduct)
      setNewProduct({})
      loadProducts()
      toast({
        title: "Success",
        description: "Product created successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create product",
        variant: "destructive",
      })
    }
  }

  const handleUpdateProduct = async (id: number, updatedData: Partial<Product>) => {
    try {
      await updateProduct(id, updatedData)
      loadProducts()
      toast({
        title: "Success",
        description: "Product updated successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update product",
        variant: "destructive",
      })
    }
  }

  const handleDeleteProduct = async (id: number) => {
    try {
      await deleteProduct(id)
      loadProducts()
      toast({
        title: "Success",
        description: "Product deleted successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete product",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Admin Panel</h1>

      <h2 className="text-2xl font-bold mb-4">Create New Product</h2>
      <form onSubmit={handleCreateProduct} className="mb-8">
        <Input
          type="text"
          placeholder="Name"
          value={newProduct.name || ""}
          onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
          className="mb-2"
        />
        <Textarea
          placeholder="Description"
          value={newProduct.description || ""}
          onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
          className="mb-2"
        />
        <Input
          type="number"
          placeholder="Price"
          value={newProduct.price || ""}
          onChange={(e) => setNewProduct({ ...newProduct, price: Number.parseFloat(e.target.value) })}
          className="mb-2"
        />
        <Button type="submit">Create Product</Button>
      </form>

      <h2 className="text-2xl font-bold mb-4">Existing Products</h2>
      <div className="space-y-4">
        {products.map((product) => (
          <div key={product.id} className="border p-4 rounded">
            <h3 className="text-xl font-bold">{product.name}</h3>
            <p>{product.description}</p>
            <p>Price: KSh {product.price.toLocaleString()}</p>
            <div className="mt-2">
              <Button onClick={() => handleUpdateProduct(product.id, { price: product.price + 100 })} className="mr-2">
                Increase Price
              </Button>
              <Button onClick={() => handleDeleteProduct(product.id)} variant="destructive">
                Delete
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

