/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  rewrites: async () => {
    return [
      {
        source: "/api/:path*",
        destination: "https://your-backend-url.vercel.app/api/:path*", // Replace with your actual backend URL
      },
    ]
  },
}

module.exports = nextConfig

