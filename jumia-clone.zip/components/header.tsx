"use client"

import { Search, ShoppingCart, User } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useStore } from "@/context/store-context"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useToast } from "@/components/ui/use-toast"
import { signOut, useSession } from "next-auth/react"
import { useRouter } from "next/navigation"

export default function Header() {
  const { state, dispatch } = useStore()
  const { cart } = state
  const { toast } = useToast()
  const { data: session } = useSession()
  const router = useRouter()

  const cartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  const handleLogout = async () => {
    await signOut({ redirect: false })
    toast({
      title: "Logged out successfully",
      description: "See you soon!",
    })
    router.push("/")
  }

  return (
    <header className="border-b sticky top-0 bg-white z-50">
      <div className="container mx-auto px-4 py-2">
        <div className="flex items-center justify-between gap-4">
          <Link href="/" className="flex-shrink-0">
            <Image src="/placeholder.svg" alt="Jumia" width={120} height={40} />
          </Link>

          <div className="flex flex-1 max-w-2xl">
            <Input type="search" placeholder="Search products, brands and categories" className="rounded-r-none" />
            <Button type="submit" className="rounded-l-none bg-orange-500 hover:bg-orange-600">
              <Search className="h-4 w-4" />
              <span className="ml-2 hidden md:inline">SEARCH</span>
            </Button>
          </div>

          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost">
                  <User className="h-4 w-4 mr-2" />
                  {session ? session.user?.name || session.user?.email : "Account"}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {session ? (
                  <>
                    <DropdownMenuItem>Profile</DropdownMenuItem>
                    <DropdownMenuItem>Orders</DropdownMenuItem>
                    <DropdownMenuItem onClick={handleLogout}>Logout</DropdownMenuItem>
                  </>
                ) : (
                  <>
                    <DropdownMenuItem onClick={() => router.push("/login")}>Login</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => router.push("/register")}>Sign Up</DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="ghost">Help</Button>
            <Button variant="ghost" className="relative" onClick={() => dispatch({ type: "TOGGLE_CART" })}>
              <ShoppingCart className="h-4 w-4" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">
                  {cartItemsCount}
                </span>
              )}
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}

