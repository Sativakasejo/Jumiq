import Link from "next/link"
import {
  Store,
  Smartphone,
  Tv,
  HomeIcon,
  Heart,
  Briefcase,
  ShoppingBag,
  Baby,
  ClubIcon as Football,
} from "lucide-react"

const categories = [
  { name: "Official Stores", icon: Store },
  { name: "Phones & Tablets", icon: Smartphone },
  { name: "TVs & Audio", icon: Tv },
  { name: "Appliances", icon: HomeIcon },
  { name: "Health & Beauty", icon: Heart },
  { name: "Home & Office", icon: Briefcase },
  { name: "Fashion", icon: ShoppingBag },
  { name: "Baby Products", icon: Baby },
  { name: "Sporting Goods", icon: Football },
]

export default function Sidebar() {
  return (
    <aside className="w-64 bg-white border-r min-h-screen p-4">
      {categories.map((category) => {
        const Icon = category.icon
        return (
          <Link
            key={category.name}
            href={`/category/${category.name.toLowerCase().replace(/ /g, "-")}`}
            className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg"
          >
            <Icon className="h-5 w-5" />
            {category.name}
          </Link>
        )
      })}
    </aside>
  )
}

