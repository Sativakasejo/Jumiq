"use client"

import type { Product } from "@/types"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { useStore } from "@/context/store-context"
import { useToast } from "@/components/ui/use-toast"
import { Star } from "lucide-react"
import Link from "next/link"

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const { dispatch } = useStore()
  const { toast } = useToast()

  const handleAddToCart = () => {
    dispatch({ type: "ADD_TO_CART", payload: product })
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    })
  }

  return (
    <Card>
      <CardContent className="p-4">
        <Link href={`/product/${product.id}`}>
          <div className="relative mb-2">
            <Image
              src={product.image || "/placeholder.svg"}
              alt={product.name}
              width={200}
              height={200}
              className="w-full"
            />
            <span className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 text-sm rounded">
              -{product.discount}%
            </span>
          </div>
          <h3 className="text-sm line-clamp-2 mb-2">{product.name}</h3>
          <div className="flex items-center mb-2">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${
                  i < Math.round(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                }`}
              />
            ))}
            <span className="ml-2 text-sm text-gray-600">({product.reviews.length})</span>
          </div>
          <div className="text-lg font-bold">KSh {product.price.toLocaleString()}</div>
          <div className="text-sm text-gray-500 line-through">KSh {product.originalPrice.toLocaleString()}</div>
          <div className="text-xs text-gray-600 mt-2 mb-4">{product.itemsLeft} items left</div>
        </Link>
        <Button onClick={handleAddToCart} className="w-full" variant="secondary">
          Add to Cart
        </Button>
      </CardContent>
    </Card>
  )
}

