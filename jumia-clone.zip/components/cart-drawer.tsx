"use client"

import { useStore } from "@/context/store-context"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Minus, Plus, Trash2 } from "lucide-react"
import Image from "next/image"

export default function CartDrawer() {
  const { state, dispatch } = useStore()
  const { cart, isCartOpen } = state

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)

  return (
    <Sheet open={isCartOpen} onOpenChange={() => dispatch({ type: "TOGGLE_CART" })}>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Shopping Cart ({cart.length} items)</SheetTitle>
        </SheetHeader>
        <div className="mt-8 space-y-4">
          {cart.map((item) => (
            <div key={item.id} className="flex gap-4">
              <Image
                src={item.image || "/placeholder.svg"}
                alt={item.name}
                width={80}
                height={80}
                className="rounded-md"
              />
              <div className="flex-1">
                <h3 className="text-sm font-medium">{item.name}</h3>
                <p className="text-sm text-muted-foreground">KSh {item.price.toLocaleString()}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      if (item.quantity === 1) {
                        dispatch({ type: "REMOVE_FROM_CART", payload: item.id })
                      } else {
                        dispatch({
                          type: "UPDATE_QUANTITY",
                          payload: { id: item.id, quantity: item.quantity - 1 },
                        })
                      }
                    }}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span>{item.quantity}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() =>
                      dispatch({
                        type: "UPDATE_QUANTITY",
                        payload: { id: item.id, quantity: item.quantity + 1 },
                      })
                    }
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="destructive"
                    size="icon"
                    onClick={() => dispatch({ type: "REMOVE_FROM_CART", payload: item.id })}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
        {cart.length > 0 ? (
          <div className="mt-8 space-y-4">
            <div className="flex justify-between text-lg font-semibold">
              <span>Total:</span>
              <span>KSh {total.toLocaleString()}</span>
            </div>
            <Button className="w-full" size="lg">
              Proceed to Checkout
            </Button>
          </div>
        ) : (
          <div className="mt-8 text-center text-muted-foreground">Your cart is empty</div>
        )}
      </SheetContent>
    </Sheet>
  )
}

