"use client"

import { useState } from "react"
import { useStore } from "@/context/store-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { createOrder } from "@/utils/api"
import { useRouter } from "next/navigation"

export default function Checkout() {
  const { state, dispatch } = useStore()
  const { cart } = state
  const { toast } = useToast()
  const router = useRouter()

  const [address, setAddress] = useState("")
  const [city, setCity] = useState("")
  const [postalCode, setPostalCode] = useState("")

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault()

    if (cart.length === 0) {
      toast({
        title: "Error",
        description: "Your cart is empty",
        variant: "destructive",
      })
      return
    }

    try {
      const order = await createOrder({
        total,
        status: "PENDING",
        items: cart.map((item) => ({
          productId: item.id,
          quantity: item.quantity,
          price: item.price,
        })),
        shippingAddress: `${address}, ${city}, ${postalCode}`,
      })

      toast({
        title: "Success",
        description: "Your order has been placed successfully",
      })

      // Clear the cart
      dispatch({ type: "CLEAR_CART" })

      // Redirect to order confirmation page
      router.push(`/order-confirmation/${order.id}`)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to place order. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="max-w-md mx-auto mt-8">
      <h2 className="text-2xl font-bold mb-4">Checkout</h2>
      <form onSubmit={handleCheckout}>
        <div className="mb-4">
          <label htmlFor="address" className="block text-sm font-medium text-gray-700">
            Address
          </label>
          <Input type="text" id="address" value={address} onChange={(e) => setAddress(e.target.value)} required />
        </div>
        <div className="mb-4">
          <label htmlFor="city" className="block text-sm font-medium text-gray-700">
            City
          </label>
          <Input type="text" id="city" value={city} onChange={(e) => setCity(e.target.value)} required />
        </div>
        <div className="mb-4">
          <label htmlFor="postalCode" className="block text-sm font-medium text-gray-700">
            Postal Code
          </label>
          <Input
            type="text"
            id="postalCode"
            value={postalCode}
            onChange={(e) => setPostalCode(e.target.value)}
            required
          />
        </div>
        <div className="mb-4">
          <h3 className="text-lg font-semibold">Order Summary</h3>
          {cart.map((item) => (
            <div key={item.id} className="flex justify-between items-center py-2">
              <span>
                {item.name} x {item.quantity}
              </span>
              <span>KSh {(item.price * item.quantity).toLocaleString()}</span>
            </div>
          ))}
          <div className="border-t pt-2 mt-2">
            <div className="flex justify-between items-center font-bold">
              <span>Total:</span>
              <span>KSh {total.toLocaleString()}</span>
            </div>
          </div>
        </div>
        <Button type="submit" className="w-full">
          Place Order
        </Button>
      </form>
    </div>
  )
}

