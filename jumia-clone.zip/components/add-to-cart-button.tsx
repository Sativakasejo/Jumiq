"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { useStore } from "@/context/store-context"
import { useToast } from "@/components/ui/use-toast"
import type { Product } from "@/types"

export default function AddToCartButton({ product }: { product: Product }) {
  const [quantity, setQuantity] = useState(1)
  const { dispatch } = useStore()
  const { toast } = useToast()

  const handleAddToCart = () => {
    dispatch({ type: "ADD_TO_CART", payload: { ...product, quantity } })
    toast({
      title: "Added to cart",
      description: `${quantity} ${quantity === 1 ? "item" : "items"} of ${product.name} added to your cart.`,
    })
  }

  return (
    <div className="flex items-center space-x-4">
      <input
        type="number"
        min="1"
        max={product.itemsLeft}
        value={quantity}
        onChange={(e) => setQuantity(Number.parseInt(e.target.value))}
        className="w-20 p-2 border rounded"
      />
      <Button onClick={handleAddToCart}>Add to Cart</Button>
    </div>
  )
}

