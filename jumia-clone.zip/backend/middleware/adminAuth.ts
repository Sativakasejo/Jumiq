import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function adminAuth(handler: (req: NextRequest) => Promise<NextResponse>) {
  return async (req: NextRequest) => {
    const authHeader = req.headers.get("Authorization")

    if (!authHeader || !authHeader.startsWith("Basic ")) {
      return new NextResponse("Unauthorized", { status: 401 })
    }

    const base64Credentials = authHeader.split(" ")[1]
    const credentials = Buffer.from(base64Credentials, "base64").toString("ascii")
    const [username, password] = credentials.split(":")

    if (username !== "admin" || password !== "kasejo") {
      return new NextResponse("Unauthorized", { status: 401 })
    }

    return handler(req)
  }
}

