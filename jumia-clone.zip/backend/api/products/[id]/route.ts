import type { NextRequest } from "next/server"
import { adminAuth } from "../../../middleware/adminAuth"

export const PUT = adminAuth(async (req: NextRequest, { params }: { params: { id: string } }) => {
  try {
    const { id } = params
    const body = await req.json()

    // ... (Existing PUT logic to update a product with id) ...

    return new Response("Product updated successfully", { status: 200 })
  } catch (error) {
    console.error("Error updating product:", error)
    return new Response("Error updating product", { status: 500 })
  }
})

export const DELETE = adminAuth(async (req: NextRequest, { params }: { params: { id: string } }) => {
  try {
    const { id } = params

    // ... (Existing DELETE logic to delete a product with id) ...

    return new Response("Product deleted successfully", { status: 200 })
  } catch (error) {
    console.error("Error deleting product:", error)
    return new Response("Error deleting product", { status: 500 })
  }
})

export const GET = async (req: NextRequest, { params }: { params: { id: string } }) => {
  try {
    const { id } = params

    // ... (Existing GET logic to fetch a product with id) ...

    return new Response(JSON.stringify(product), { status: 200 })
  } catch (error) {
    console.error("Error fetching product:", error)
    return new Response("Error fetching product", { status: 500 })
  }
}

