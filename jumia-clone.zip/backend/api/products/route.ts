import type { NextRequest } from "next/server"
import { adminAuth } from "../../middleware/adminAuth"

export const POST = adminAuth(async (req: NextRequest) => {
  try {
    const { name, description, price, image } = await req.json()

    if (!name || !description || !price || !image) {
      return new Response("Missing required fields", { status: 400 })
    }

    // Database interaction (replace with your actual database logic)
    // ... (Example using a mock database)
    const products = []
    const newProduct = {
      id: products.length + 1,
      name,
      description,
      price,
      image,
    }
    products.push(newProduct)

    return new Response(JSON.stringify(newProduct), {
      status: 201,
      headers: {
        "Content-Type": "application/json",
      },
    })
  } catch (error) {
    console.error("Error creating product:", error)
    return new Response("Failed to create product", { status: 500 })
  }
})

export const GET = async (req: NextRequest) => {
  // Database interaction (replace with your actual database logic)
  // ... (Example using a mock database)
  const products = [
    { id: 1, name: "Product 1", description: "Description 1", price: 10, image: "image1.jpg" },
    { id: 2, name: "Product 2", description: "Description 2", price: 20, image: "image2.jpg" },
  ]

  return new Response(JSON.stringify(products), {
    status: 200,
    headers: {
      "Content-Type": "application/json",
    },
  })
}

